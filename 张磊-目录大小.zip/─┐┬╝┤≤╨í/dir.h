#ifndef DIR_H
#define DIR_H

void dir(char* value, SegQueue* list);


#endif